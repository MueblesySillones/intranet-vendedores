/* ════════════════════ TUTORIALES ════════════════════
   Videos instructivos con LÍNEA DE TIEMPO, como los capítulos de YouTube.

   Así lo pidió el equipo: «una pantalla donde se pueden cargar videos de
   tutoriales, que se pueda ver en pantalla completa y grande, y que tenga una
   línea de tiempo donde se coloca el minuto con el tutorial. Por ejemplo,
   minuto 3:25 "cómo editar módulos", y en la misma línea minuto 5 "cómo subir
   una publicación". Esto tiene que ser editable y ajustable».

   CÓMO FUNCIONA LA LÍNEA, Y POR QUÉ ASÍ

   La barra no es una barra sola: son TRAMOS, uno por capítulo, separados por
   una ranura —igual que YouTube—. El ancho de cada tramo es lo que dura ese
   capítulo, así que de un vistazo se ve cuánto ocupa cada tema. Adentro de
   cada tramo se llena lo que ya se vio.

   ⚠️ El tiempo de un capítulo se pone MIRANDO EL VIDEO: se pausa donde
   corresponde y se aprieta «Marcar acá». Escribir «3:25» a mano también se
   puede, pero pedirlo como única forma obliga a anotar los minutos en un papel
   mientras se mira. Igual se puede corregir escribiendo, porque el que grabó
   el video no siempre es el que carga los capítulos.

   ⚠️ Los capítulos se guardan ORDENADOS y sin repetir el segundo. Dos marcas
   en el mismo lugar no se pueden dibujar, y desordenadas «el capítulo de
   ahora» saltaría para atrás mientras el video avanza.

   QUIÉN PUEDE QUÉ

   Mirar, todos. Subir y editar, solo la central: un tutorial es material que
   se hace una vez y lo ve todo el mundo, igual que un módulo.
   ════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var LISTA = [];        // los tutoriales cargados
  var ABIERTO = null;    // el que se está mirando, o null si es la lista
  var EDIT = false;      // editando los capítulos del abierto
  var BUSCA = '';        // lo que se escribió en la lupa (ya normalizado)
  var CAPS = [];         // los capítulos mientras se editan (el borrador)
  var CARGADO = false;
  var PARTE = 0;         // cuál de los videos del tutorial está cargado

  /* ───────────── VARIOS VIDEOS, UNA SOLA LÍNEA ─────────────
     26-sep-2026, pedido del dueño: «tengo tres videos que explican los
     módulos y no quiero tres tarjetas: que todo esté dentro de una y se
     puedan ir agregando videos a la línea de tiempo».
     Un tutorial tiene su video (`src`) y los que le siguen (`mas`). Se
     reproducen uno detrás del otro y la línea de tiempo es UNA: los minutos
     de los capítulos cuentan sobre el total, así que el capítulo del segundo
     video de 3 minutos, si el primero dura 5, está en el 8:00. Por eso la
     lupa, «Marcar acá» y saltar a un capítulo siguen hablando en minutos
     de la línea entera, y el reproductor traduce a «qué video y qué segundo». */
  function partes(t) {
    var l = t ? [{ src: t.src, duracion: t.duracion || 0 }].concat(t.mas || []) : [];
    var v = video();
    var desde = 0;
    return l.map(function (x, i) {
      var d = x.duracion || 0;
      /* el que está cargado sabe su duración exacta aunque no se haya guardado */
      if (i === PARTE && t && t.id === ABIERTO && v && isFinite(v.duration) && v.duration > 0) {
        d = v.duration;
      }
      var o = { src: x.src, duracion: d, desde: desde, i: i };
      desde += d;
      return o;
    });
  }

  function durDe(t) {
    return partes(t).reduce(function (a, x) { return a + x.duracion; }, 0);
  }

  /* el segundo de la línea ENTERA en el que se está */
  function ahora() {
    var v = video();
    var p = partes(elDe(ABIERTO))[PARTE];
    return (p ? p.desde : 0) + ((v && v.currentTime) || 0);
  }

  function cargarParte(i, local, seguir) {
    var v = video(), t = elDe(ABIERTO);
    var ps = partes(t);
    if (!v || !ps[i]) return;
    PARTE = i;
    v.src = url(ps[i].src);
    v.addEventListener('loadedmetadata', function () {
      v.currentTime = Math.max(0, local || 0);
      if (seguir) v.play().catch(function () {});
      alCorrer();
    }, { once: true });
    pintarCaps();
  }

  /* ir a un minuto de la línea ENTERA: si cae en otro video, se cambia */
  function irA(seg, tocar) {
    var v = video();
    var ps = partes(elDe(ABIERTO));
    if (!v || !ps.length) return;
    var i = ps.length - 1;
    for (var k = 0; k < ps.length; k++) {
      if (seg < ps[k].desde + ps[k].duracion) { i = k; break; }
    }
    var local = Math.max(0, seg - ps[i].desde);
    if (i !== PARTE) { cargarParte(i, local, tocar || !v.paused); return; }
    var poner = function () { v.currentTime = local; if (tocar) v.play().catch(function () {}); alCorrer(); };
    if (v.readyState >= 1) poner(); else v.addEventListener('loadedmetadata', poner, { once: true });
  }

  function esc(t) {
    return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function aviso(t, tipo) { if (window.toast) window.toast(t, tipo || 'ok'); }

  /* ⚠️ `ES_CENTRAL` es un `let` de app.js, no una propiedad de window: un
     `let` del ámbito global NO se cuelga de window, así que `window.ES_CENTRAL`
     siempre daría undefined y todas las sucursales se creerían la central. Se
     lee por nombre, con `typeof` para no explotar si app.js no cargó. */
  function central() {
    try {
      return (typeof ES_CENTRAL === 'undefined') ? true : ES_CENTRAL !== false;
    } catch (e) {
      return true;
    }
  }

  function raiz() { return document.getElementById('tutRaiz'); }

  function video() { return document.getElementById('tutVideo'); }

  /* ⚠️ El `src` se guarda RELATIVO —«assets/_tutoriales/x.mp4»— porque así lo
     necesita la intranet publicada, que se sirve desde su propia raíz. Pero el
     panel vive en otra: acá los archivos de la intranet salen por
     `/intranet/…`, y sin el prefijo el video daba 404 y el reproductor quedaba
     en negro sin decir por qué. */
  function url(src) {
    src = String(src || '');
    return src.charAt(0) === '/' ? src : '/intranet/' + src;
  }

  /* ───────────── el tiempo, escrito y leído ─────────────
     Un tutorial de 8 minutos no necesita horas; uno de una hora sí. El formato
     sale del número, no de una preferencia. */
  function reloj(seg) {
    seg = Math.max(0, Math.floor(seg || 0));
    var h = Math.floor(seg / 3600), m = Math.floor((seg % 3600) / 60), s = seg % 60;
    var dd = function (n) { return (n < 10 ? '0' : '') + n; };
    return h ? (h + ':' + dd(m) + ':' + dd(s)) : (m + ':' + dd(s));
  }

  /* «3:25» → 205. Acepta «205», «3:25» y «1:03:25». Devuelve null si no se
     entiende, para no convertir un error de tipeo en un salto al segundo 0. */
  function segundos(txt) {
    var partes = String(txt || '').trim().split(':');
    if (!partes.length || partes.some(function (p) { return !/^\d{1,3}$/.test(p.trim()); })) {
      return null;
    }
    var n = 0;
    for (var i = 0; i < partes.length; i++) n = n * 60 + parseInt(partes[i], 10);
    return n;
  }

  /* ───────────── traer y guardar ───────────── */
  function cargar() {
    return window.api('/api/tutoriales').then(function (r) {
      LISTA = (r && r.tutoriales) || [];
      CARGADO = true;
      pintar();
    }).catch(function () {
      LISTA = []; CARGADO = true; pintar();
    });
  }

  function guardar(lista, dice) {
    return window.api('/api/tutoriales', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tutoriales: lista })
    }).then(function (r) {
      if (r && r.error) throw new Error(r.error);
      LISTA = (r && r.tutoriales) || lista;
      if (dice) aviso(dice, 'ok');
      /* un tutorial cambiado es un cambio sin publicar, como cualquier otro */
      if (window.marcarOtroCambio) window.marcarOtroCambio();
      return LISTA;
    });
  }

  function elDe(id) {
    return LISTA.filter(function (t) { return t.id === id; })[0] || null;
  }

  /* ───────────── la pantalla ───────────── */
  function pintar() {
    var r = raiz();
    if (!r) return;
    if (ABIERTO && elDe(ABIERTO)) { pintarUno(elDe(ABIERTO)); return; }
    ABIERTO = null;
    pintarLista();
  }

  /* ───────────── buscar ─────────────
     Pedido del usuario (22-sep): "que haga una lupa para buscar la pregunta,
     por ejemplo si busca modulo le aparezca los videos relacionados a los
     modulos". Busca en el título, en la descripción y —lo que importa— en el
     TEXTO DE LOS CAPÍTULOS: ahí es donde dice de qué habla cada tramo. Un
     resultado puede ser "este video, en el minuto 3:25". */
  function norm(x) {
    return String(x || '').toLowerCase()
      .replace(/[áàä]/g, 'a').replace(/[éèë]/g, 'e').replace(/[íìï]/g, 'i')
      .replace(/[óòö]/g, 'o').replace(/[úùü]/g, 'u').replace(/ñ/g, 'n');
  }

  function capsQueCoinciden(t, q) {
    if (!q) return [];
    return (t.capitulos || []).filter(function (c) { return norm(c.texto).indexOf(q) >= 0; })
      .slice().sort(function (a, b) { return a.t - b.t; });
  }

  function coincide(t, q) {
    if (!q) return true;
    return norm(t.titulo).indexOf(q) >= 0 || norm(t.nota).indexOf(q) >= 0 ||
           capsQueCoinciden(t, q).length > 0;
  }

  /* La barra de arriba se dibuja UNA vez: si se repintara con cada tecla, el
     campo perdería el foco en la primera letra. */
  function pintarBarra() {
    var der = document.getElementById('tutDer');
    if (!der || der.dataset.listo) return;
    der.dataset.listo = '1';
    der.innerHTML =
      '<span class="campo-wrap">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">' +
        '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>' +
        '<input class="campo" id="tutBuscar" type="search" autocomplete="off" ' +
        'placeholder="Buscar un tema: módulos, publicar..."></span>' +
      (central() ? '<button type="button" class="btn active" id="tutNuevo">Subir un tutorial</button>' : '');
    var campo = document.getElementById('tutBuscar');
    campo.oninput = function () {
      BUSCA = norm(campo.value).trim();
      ABIERTO = null;                  /* buscar siempre devuelve a la lista */
      EDIT = false;
      pintarLista();
    };
    if (central()) document.getElementById('tutNuevo').onclick = abrirSubir;
  }

  function pintarLista() {
    var r = raiz();
    var puede = central();
    pintarBarra();
    var hay = LISTA.filter(function (t) { return coincide(t, BUSCA); });
    r.innerHTML =
      (BUSCA
        ? '<p class="tut-res">' + (hay.length
            ? hay.length + (hay.length === 1 ? ' tutorial habla' : ' tutoriales hablan') + ' de “' + esc(BUSCA) + '”'
            : 'Ningún tutorial habla de “' + esc(BUSCA) + '”') + '</p>'
        : '') +
      (hay.length
        ? '<div class="tut-l">' + hay.map(tarjeta).join('') + '</div>'
        : (LISTA.length
            ? ''
            : '<p class="dt-chico" id="tutVacio">' +
              (puede
                ? 'Todavía no hay ninguno. Un tutorial es un video —cómo editar un módulo, cómo subir una publicación— con una línea de tiempo adentro: marcás el minuto donde empieza cada tema y después se puede saltar directo a eso.'
                : 'Todavía no hay tutoriales cargados. Los sube la central y aparecen acá cuando traés la última versión.') +
              '</p>'));
  }

  function tarjeta(t) {
    var n = (t.capitulos || []).length;
    var nv = 1 + (t.mas || []).length;
    /* los tramos que coinciden con lo buscado: se entra directo al minuto */
    var hits = capsQueCoinciden(t, BUSCA).slice(0, 4).map(function (c) {
      return '<button type="button" class="tut-hit" data-ver-tut="' + esc(t.id) +
        '" data-t="' + c.t + '"><span>' + esc(reloj(c.t)) + '</span>' +
        esc(c.texto) + '</button>';
    }).join('');
    return '<article class="tut-c" data-tut="' + esc(t.id) + '">' +
      (central() ? '<button type="button" class="tut-x" data-borrar-tut="' + esc(t.id) +
        '" title="Quitar este tutorial">×</button>' : '') +
      '<div class="tut-cp">' + esc(reloj(durDe(t))) +
        (nv > 1 ? ' · ' + nv + ' videos' : '') +
        (n ? ' · ' + n + (n === 1 ? ' capítulo' : ' capítulos') : '') + '</div>' +
      '<h4 class="tut-cn">' + esc(t.titulo) + '</h4>' +
      (t.nota ? '<p class="tut-cd">' + esc(t.nota) + '</p>' : '') +
      (hits ? '<div class="tut-hits">' + hits + '</div>' : '') +
      '<div class="tut-cb"><button type="button" class="btn active" data-ver-tut="' +
        esc(t.id) + '">Ver el tutorial</button></div>' +
      '</article>';
  }

  /* Los íconos del reproductor, dibujados y no escritos: un ▶ de texto cambia
     de forma y de tamaño según la tipografía que tenga la máquina. */
  var ICONOS = {
    play: '<path d="M8 5v14l11-7z"/>',
    pausa: '<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/>',
    son: '<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/>',
    mudo: '<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="m17 9 4 6M21 9l-4 6"/>',
    full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>'
  };

  function icono(k) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
      ICONOS[k] + '</svg>';
  }

  function alternar() {
    var v = video();
    if (!v) return;
    if (v.paused) { v.play().catch(function () {}); } else { v.pause(); }
  }

  function mudo() {
    var v = video();
    if (!v) return;
    v.muted = !v.muted;
    var b = document.getElementById('tutMudo');
    if (b) {
      b.innerHTML = icono(v.muted ? 'mudo' : 'son');
      b.title = v.muted ? 'Con sonido' : 'Silenciar';
    }
  }

  function pintarPlay() {
    var v = video(), b = document.getElementById('tutPlay');
    if (!v || !b) return;
    b.innerHTML = icono(v.paused ? 'play' : 'pausa');
    b.title = v.paused ? 'Reproducir' : 'Pausar';
  }

  /* ───────────── el reproductor ───────────── */
  function pintarUno(t) {
    var r = raiz();
    var puede = central();
    CAPS = (t.capitulos || []).map(function (c) { return { t: c.t, texto: c.texto }; });
    PARTE = 0;
    /* 22-sep, pedido del usuario: el video a un costado y al lado la línea de
       temas, como en las plataformas de cursos. El reproductor y la línea de
       capítulos son los MISMOS de antes (misma caja, mismos controles, misma
       pantalla completa): lo que cambia es que la lista de capítulos pasa de
       abajo del video a una columna al costado, siempre a la vista. */
    r.innerHTML =
      '<div class="tut-h">' +
        '<button type="button" class="btn" id="tutVolver">‹ Tutoriales</button>' +
        '<div class="tut-ht"><h3>' + esc(t.titulo) + '</h3>' +
          (t.nota ? '<p>' + esc(t.nota) + '</p>' : '') + '</div>' +
      '</div>' +
      '<div class="tut-pro">' +
      '<div class="tut-izq">' +
      '<div class="tut-caja" id="tutCaja">' +
        /* ⚠️ SIN `controls`: el navegador trae su propia barra de progreso y
           quedaba una arriba de la otra con la de capítulos. Acá la barra de
           capítulos ES la barra de progreso, que es de lo que se trata. */
        '<video id="tutVideo" playsinline preload="metadata" ' +
          'src="' + esc(url(t.src)) + '"></video>' +
        /* la línea va PEGADA abajo del video y adentro de la misma caja: en
           pantalla completa tiene que seguir estando, que es donde más sirve */
        '<div class="tut-linea">' +
          '<div class="tut-barra" id="tutBarra"></div>' +
          '<div class="tut-ctrl">' +
            '<button type="button" class="tut-b" id="tutPlay" title="Reproducir">' +
              icono('play') + '</button>' +
            '<span class="tut-reloj"><span id="tutAhora">0:00</span> / ' +
              '<span id="tutDur">0:00</span></span>' +
            '<b id="tutCapAhora"></b>' +
            '<button type="button" class="tut-b" id="tutMudo" title="Silenciar">' +
              icono('son') + '</button>' +
            '<button type="button" class="tut-b" id="tutFull" title="Pantalla completa">' +
              icono('full') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="tut-bajo">' +
        (puede ? '<button type="button" class="btn" id="tutEditar">✎ Editar capítulos</button>' +
                 '<button type="button" class="btn" id="tutSumar">+ Sumar otro video</button>' +
                 '<input type="file" id="tutSumarArch" hidden multiple ' +
                   'accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm">' +
                 '<span class="dt-chico" id="tutSumarPaso" hidden></span>' +
                 '<button type="button" class="btn active" id="tutGuardar" hidden>Guardar capítulos</button>' +
                 '<button type="button" class="btn" id="tutCancelar" hidden>Cancelar</button>' +
                 '<button type="button" class="btn" id="tutMarcar" hidden>+ Marcar acá</button>' : '') +
      '</div>' +
      '</div>' +                                   /* fin de la columna del video */
      '<aside class="tut-lado">' +
        '<div class="tut-lado-t">Temas de este tutorial' +
          '<span id="tutCuenta">' + CAPS.length + '</span></div>' +
        '<div class="tut-caps" id="tutCaps"></div>' +
        otrosTutoriales(t) +
      '</aside>' +
      '</div>';

    document.getElementById('tutVolver').onclick = function () {
      if (EDIT && !window.confirm('Estás editando los capítulos. ¿Salir sin guardar?')) return;
      EDIT = false; ABIERTO = null; pintar();
    };
    document.getElementById('tutFull').onclick = pantallaCompleta;
    document.getElementById('tutPlay').onclick = alternar;
    document.getElementById('tutMudo').onclick = mudo;
    if (puede) {
      document.getElementById('tutEditar').onclick = function () { modoEdicion(true); };
      document.getElementById('tutCancelar').onclick = function () {
        CAPS = (elDe(ABIERTO).capitulos || []).map(function (c) {
          return { t: c.t, texto: c.texto };
        });
        modoEdicion(false);
      };
      document.getElementById('tutGuardar').onclick = guardarCaps;
      document.getElementById('tutMarcar').onclick = marcarAca;
      var arch = document.getElementById('tutSumarArch');
      document.getElementById('tutSumar').onclick = function () { arch.click(); };
      arch.onchange = function () {
        var fs = [].slice.call(arch.files || []);
        arch.value = '';
        if (fs.length) sumarVideos(fs);
      };
    }
    engancharVideo(t);
    pintarCaps();
    dibujarLinea();
  }

  /* Para saltar a otro tutorial sin volver a la lista: lo mismo que ofrece
     cualquier curso al costado del video. */
  function otrosTutoriales(t) {
    var otros = LISTA.filter(function (x) { return x.id !== t.id; });
    if (!otros.length) return '';
    return '<div class="tut-lado-t tut-lado-t2">Otros tutoriales</div>' +
      '<div class="tut-otros">' + otros.map(function (x, i) {
        var n = (x.capitulos || []).length;
        return '<button type="button" class="tut-otro" data-ver-tut="' + esc(x.id) + '">' +
          '<span class="tut-num">' + (i + 1) + '</span>' +
          '<span class="tut-otro-tx"><b>' + esc(x.titulo) + '</b>' +
          '<i>' + esc(reloj(durDe(x))) + (n ? ' · ' + n + (n === 1 ? ' tema' : ' temas') : '') +
          '</i></span></button>';
      }).join('') + '</div>';
  }

  function engancharVideo(t) {
    var v = video();
    if (!v) return;
    v.addEventListener('loadedmetadata', function () {
      dibujarLinea();
      var d = document.getElementById('tutDur');
      if (d) d.textContent = reloj(durDe(elDe(ABIERTO)));
      /* la duración se guarda la primera vez que alguien lo abre: así la lista
         la puede mostrar sin tener que bajar cada video. Vale para cada uno de
         los videos del tutorial. */
      var tt = elDe(ABIERTO);
      if (!tt || !central() || !isFinite(v.duration) || v.duration <= 0) return;
      var seg = Math.round(v.duration);
      var copia = null;
      if (PARTE === 0 && !tt.duracion) {
        copia = Object.assign({}, tt, { duracion: seg });
      } else if (PARTE > 0 && tt.mas && tt.mas[PARTE - 1] && !tt.mas[PARTE - 1].duracion) {
        var mas = tt.mas.map(function (x, i) {
          return i === PARTE - 1 ? Object.assign({}, x, { duracion: seg }) : x;
        });
        copia = Object.assign({}, tt, { mas: mas });
      }
      if (copia) {
        guardar(LISTA.map(function (x) { return x.id === tt.id ? copia : x; })).catch(function () {});
      }
    });
    /* al terminar un video, sigue el próximo: la línea es una sola */
    v.addEventListener('ended', function () {
      var ps = partes(elDe(ABIERTO));
      if (PARTE < ps.length - 1) cargarParte(PARTE + 1, 0, true);
    });
    v.addEventListener('timeupdate', alCorrer);
    v.addEventListener('seeked', alCorrer);
    v.addEventListener('play', pintarPlay);
    v.addEventListener('pause', pintarPlay);
    v.addEventListener('ended', pintarPlay);
    /* Si el video no carga (no está en esta computadora y tampoco hay
       internet para pedírselo al sitio), se DICE. Antes quedaba el cuadro
       negro y parecía que el tutorial andaba mal. */
    v.addEventListener('error', function () {
      var caja = document.getElementById('tutCaja');
      if (!caja || caja.querySelector('.tut-falla')) return;
      var m = document.createElement('div');
      m.className = 'tut-falla';
      m.innerHTML = '<b>No se pudo abrir el video</b>' +
        '<span>Revisá que esta computadora tenga internet y volvé a intentar. ' +
        'Si sigue igual, tocá Actualizar para bajar la última versión.</span>';
      caja.appendChild(m);
    });
    /* tocar el video lo arranca y lo para, como en cualquier reproductor */
    v.addEventListener('click', alternar);
    pintarPlay();
  }

  /* Teclas, mientras se está mirando un tutorial: espacio arranca y para, las
     flechas mueven cinco segundos. ⚠️ No cuando el foco está en un campo: si
     no, escribir el texto de un capítulo pausaría el video en cada espacio. */
  document.addEventListener('keydown', function (ev) {
    var v = video();
    if (!v || !ABIERTO) return;
    var d = document.activeElement;
    if (d && (d.tagName === 'INPUT' || d.tagName === 'TEXTAREA' || d.isContentEditable)) {
      return;
    }
    if (ev.key === ' ' || ev.key === 'k') { ev.preventDefault(); alternar(); }
    else if (ev.key === 'ArrowRight') { ev.preventDefault(); irA(ahora() + 5); }
    else if (ev.key === 'ArrowLeft') { ev.preventDefault(); irA(Math.max(0, ahora() - 5)); }
  });

  /* ───────────── la línea de tiempo ─────────────
     Un tramo por capítulo, con una ranura entre uno y otro. El ancho de cada
     tramo es lo que dura ese capítulo: de un vistazo se ve cuánto ocupa cada
     tema, que es justo lo que se quiere de una línea de tiempo. */
  function tramos() {
    var t = elDe(ABIERTO) || {};
    var ps = partes(t);
    var dur = durDe(t);
    var caps = (EDIT ? CAPS : (t.capitulos || []))
      .slice().sort(function (a, b) { return a.t - b.t; });
    if (!dur) return { dur: 0, lista: [] };
    var puntos = caps.filter(function (c) { return c.t < dur; })
      .map(function (c) { return { t: c.t, texto: c.texto, ct: c.t }; });
    if (!puntos.length || puntos[0].t > 0) {
      puntos = [{ t: 0, texto: '', ct: null }].concat(puntos);
    }
    /* donde empieza cada video la línea también se corta, aunque ahí no haya
       capítulo: el tramo sigue siendo del capítulo que venía */
    var cortes = {};
    ps.slice(1).forEach(function (x) {
      if (x.desde <= 0 || x.desde >= dur) return;
      cortes[Math.round(x.desde * 1000)] = true;
      if (!puntos.some(function (c) { return Math.abs(c.t - x.desde) < 0.001; })) {
        puntos.push({ t: x.desde, texto: null, ct: null });
      }
    });
    puntos.sort(function (a, b) { return a.t - b.t; });
    for (var k = 0; k < puntos.length; k++) {
      if (puntos[k].texto === null) {
        puntos[k].texto = k ? puntos[k - 1].texto : '';
        puntos[k].ct = k ? puntos[k - 1].ct : null;
      }
    }
    var lista = puntos.map(function (c, i) {
      var fin = (i + 1 < puntos.length) ? puntos[i + 1].t : dur;
      return { desde: c.t, hasta: fin, texto: c.texto, ct: c.ct, i: i,
               corte: !!cortes[Math.round(c.t * 1000)] };
    });
    return { dur: dur, lista: lista };
  }

  function dibujarLinea() {
    var caja = document.getElementById('tutBarra');
    if (!caja) return;
    var d = tramos();
    if (!d.dur) { caja.innerHTML = '<div class="tut-seg" style="flex-grow:1"><i></i></div>'; return; }
    caja.innerHTML = d.lista.map(function (s) {
      var largo = Math.max(0.5, s.hasta - s.desde);
      return '<div class="tut-seg' + (s.corte ? ' corte' : '') + '" style="flex-grow:' + largo + '" data-t="' + s.desde +
        '"' + (s.texto ? ' title="' + esc(reloj(s.desde) + ' · ' + s.texto) + '"' : '') +
        '><i></i></div>';
    }).join('');
    caja.onclick = function (ev) {
      var tot = durDe(elDe(ABIERTO));
      if (!tot) return;
      /* Se busca el TRAMO tocado y se reparte adentro de él: entre tramo y
         tramo hay una ranura, y una regla de tres sobre el ancho entero se
         corre un poco en una línea con muchos cortes. */
      var seg = ev.target.closest && ev.target.closest('.tut-seg');
      var d = tramos();
      var i = seg ? Array.prototype.indexOf.call(caja.children, seg) : -1;
      if (i >= 0 && d.lista[i]) {
        var r1 = seg.getBoundingClientRect();
        var f1 = Math.min(1, Math.max(0, (ev.clientX - r1.left) / r1.width));
        irA(d.lista[i].desde + f1 * (d.lista[i].hasta - d.lista[i].desde));
        return;
      }
      var r = caja.getBoundingClientRect();
      var f = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
      irA(f * tot);
    };
    alCorrer();
  }

  function alCorrer() {
    var v = video();
    if (!v) return;
    var d = tramos();
    var ya = ahora();
    var caja = document.getElementById('tutBarra');
    if (caja) {
      var segs = caja.querySelectorAll('.tut-seg');
      for (var i = 0; i < segs.length && i < d.lista.length; i++) {
        var s = d.lista[i];
        var largo = Math.max(0.001, s.hasta - s.desde);
        var parte = Math.min(1, Math.max(0, (ya - s.desde) / largo));
        segs[i].firstChild.style.width = (parte * 100) + '%';
        segs[i].classList.toggle('on', ya >= s.desde && ya < s.hasta);
      }
    }
    var t = document.getElementById('tutAhora');
    if (t) t.textContent = reloj(ya);
    var cual = null;
    for (var j = 0; j < d.lista.length; j++) {
      if (ya >= d.lista[j].desde) cual = d.lista[j];
    }
    var b = document.getElementById('tutCapAhora');
    if (b) b.textContent = (cual && cual.texto) || '';
    var filas = document.querySelectorAll('#tutCaps .tut-cap');
    for (var k = 0; k < filas.length; k++) {
      filas[k].classList.toggle('on',
        cual != null && cual.ct != null && parseInt(filas[k].dataset.t, 10) === cual.ct);
    }
  }

  /* ───────────── la lista de capítulos ───────────── */
  function pintarCaps() {
    var caja = document.getElementById('tutCaps');
    if (!caja) return;
    var caps = (EDIT ? CAPS : ((elDe(ABIERTO) || {}).capitulos || []))
      .slice().sort(function (a, b) { return a.t - b.t; });
    var ps = partes(elDe(ABIERTO));
    /* con más de un video, la lista se agrupa: «Video 2 · desde 5:12» */
    var cab = function (x) {
      return '<div class="tut-vid-h' + (x.i === PARTE ? ' on' : '') + '" data-parte="' + x.i + '">' +
        '<span>Video ' + (x.i + 1) + ' · desde ' + esc(reloj(x.desde)) + '</span>' +
        (central() && !EDIT
          ? '<button type="button" class="tut-quitar-vid" data-quitar-parte="' + x.i +
            '" title="Quitar este video del tutorial">×</button>' : '') +
        '</div>';
    };
    var puestos = 0;
    var antes = function (tt) {
      if (ps.length < 2) return '';
      var h = '';
      while (puestos < ps.length && (puestos === 0 || ps[puestos].desde <= tt)) {
        h += cab(ps[puestos]); puestos++;
      }
      return h;
    };
    if (!caps.length) {
      /* sin capítulos igual se listan los videos: es la forma de ir directo
         al segundo para marcarle los suyos */
      caja.innerHTML = antes(Infinity) + '<p class="dt-chico">' +
        (EDIT
          ? 'Todavía no hay capítulos. Poné el video donde empieza un tema y apretá <b>+ Marcar acá</b>.'
          : 'Este tutorial todavía no tiene capítulos marcados.') + '</p>';
      return;
    }
    caja.innerHTML = caps.map(function (c, i) {
      return antes(c.t) + fila(c, i);
    }).join('') + antes(Infinity);
    function fila(c, i) {
      if (EDIT) {
        return '<div class="tut-cap edit" data-t="' + c.t + '" data-i="' + i + '">' +
          '<input class="tut-t" value="' + esc(reloj(c.t)) + '" data-campo="t" ' +
            'inputmode="numeric" aria-label="Minuto">' +
          '<input class="tut-x2" value="' + esc(c.texto) + '" data-campo="texto" ' +
            'maxlength="120" placeholder="De qué habla acá">' +
          '<button type="button" class="tut-quitar" title="Quitar este capítulo">×</button>' +
          '</div>';
      }
      return '<button type="button" class="tut-cap" data-t="' + c.t + '">' +
        '<span class="tut-t">' + esc(reloj(c.t)) + '</span>' +
        '<span class="tut-x2">' + esc(c.texto) + '</span></button>';
    }
    if (EDIT) engancharEdicion(caja);
    var cuenta = document.getElementById('tutCuenta');
    if (cuenta) cuenta.textContent = caps.length;   /* al marcar uno nuevo, el número sube */
    alCorrer();
  }

  function engancharEdicion(caja) {
    var filas = caja.querySelectorAll('.tut-cap.edit');
    for (var i = 0; i < filas.length; i++) {
      (function (fila) {
        var idx = parseInt(fila.dataset.i, 10);
        var tt = fila.querySelector('[data-campo="t"]');
        var tx = fila.querySelector('[data-campo="texto"]');
        var orden = CAPS.slice().sort(function (a, b) { return a.t - b.t; });
        var cap = orden[idx];
        tt.onchange = function () {
          var n = segundos(tt.value);
          if (n === null) {
            aviso('El minuto se escribe como 3:25', 'err');
            tt.value = reloj(cap.t);
            return;
          }
          cap.t = n;
          pintarCaps(); dibujarLinea();
        };
        tx.oninput = function () { cap.texto = tx.value; };
        tx.onchange = function () { dibujarLinea(); };
        fila.querySelector('.tut-quitar').onclick = function () {
          CAPS = CAPS.filter(function (c) { return c !== cap; });
          pintarCaps(); dibujarLinea();
        };
      }(filas[i]));
    }
  }

  function modoEdicion(v) {
    EDIT = v;
    ['tutGuardar', 'tutCancelar', 'tutMarcar'].forEach(function (id) {
      var e = document.getElementById(id);
      if (e) e.hidden = !v;
    });
    ['tutEditar', 'tutSumar'].forEach(function (id) {
      var e = document.getElementById(id);
      if (e) e.hidden = v;
    });
    pintarCaps();
    dibujarLinea();
    if (v) {
      aviso('Poné el video donde empieza un tema y apretá «+ Marcar acá»', 'ok');
    }
  }

  function marcarAca() {
    var v = video();
    if (!v) return;
    var seg = Math.floor(ahora());
    if (CAPS.some(function (c) { return c.t === seg; })) {
      aviso('Ya hay un capítulo en ' + reloj(seg), 'err');
      return;
    }
    CAPS.push({ t: seg, texto: '' });
    pintarCaps(); dibujarLinea();
    /* el foco va al texto del capítulo recién marcado: marcarlo y no poder
       escribir de qué habla obligaría a buscarlo con el mouse */
    var orden = CAPS.slice().sort(function (a, b) { return a.t - b.t; });
    var i = orden.findIndex(function (c) { return c.t === seg; });
    var fila = document.querySelector('#tutCaps .tut-cap.edit[data-i="' + i + '"]');
    if (fila) { var tx = fila.querySelector('[data-campo="texto"]'); if (tx) tx.focus(); }
  }

  function guardarCaps() {
    var t = elDe(ABIERTO);
    if (!t) return;
    var sinTexto = CAPS.filter(function (c) { return !String(c.texto || '').trim(); });
    if (sinTexto.length) {
      aviso('Hay ' + sinTexto.length + ' capítulo(s) sin texto: escribí de qué habla o quitalos', 'err');
      return;
    }
    /* 23-sep-2026 (auditoría): se aceptaba un capítulo en 5:00 de un video de
       0:29; nunca se marcaba y quedaba como fantasma en la lista y la lupa. */
    var dur = durDe(t);
    if (dur > 0) {
      var fuera = CAPS.filter(function (c) { return c.t >= dur; });
      if (fuera.length) {
        aviso('El video dura ' + reloj(dur) + ': ' +
              (fuera.length === 1 ? 'el capítulo en ' + reloj(fuera[0].t) + ' queda'
                                  : fuera.length + ' capítulos quedan') +
              ' después del final. Corregí el minuto o quitalo.', 'err');
        return;
      }
    }
    var btn = document.getElementById('tutGuardar');
    btn.disabled = true; btn.textContent = 'Guardando…';
    var copia = LISTA.map(function (x) {
      return x.id === t.id ? Object.assign({}, x, { capitulos: CAPS.slice() }) : x;
    });
    guardar(copia, 'Capítulos guardados').then(function () {
      btn.disabled = false; btn.textContent = 'Guardar capítulos';
      modoEdicion(false);
    }).catch(function (e) {
      btn.disabled = false; btn.textContent = 'Guardar capítulos';
      aviso(e.message || 'No se pudo guardar', 'err');
    });
  }

  /* ⚠️ Pantalla completa sobre la CAJA, no sobre el <video>: si fuera el video,
     el navegador pone sus controles y la línea de capítulos —que es para lo que
     se hizo esto— desaparece justo cuando más se ve. */
  function pantallaCompleta() {
    var caja = document.getElementById('tutCaja');
    if (!caja) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else if (caja.requestFullscreen) {
      caja.requestFullscreen().catch(function () {
        var v = video();
        if (v && v.requestFullscreen) v.requestFullscreen();
      });
    }
  }

  /* ───────────── subir uno nuevo ───────────── */
  function abrirSubir() {
    if (window.exigirActualizacion && window.exigirActualizacion()) return;
    var modal = document.getElementById('tutModal');
    if (!modal) return;
    document.getElementById('tutTitulo').value = '';
    document.getElementById('tutNota').value = '';
    document.getElementById('tutArchivo').value = '';
    var e = document.getElementById('tutSubirMal');
    if (e) { e.hidden = true; e.textContent = ''; }
    var p = document.getElementById('tutSubirPaso');
    if (p) { p.hidden = true; p.textContent = ''; }
    if (window.abrirModal) window.abrirModal(modal);
    setTimeout(function () {
      var i = document.getElementById('tutTitulo');
      if (i) i.focus();
    }, 60);
  }

  function cerrarSubir() {
    var modal = document.getElementById('tutModal');
    if (window.esconderModal) window.esconderModal(modal);
  }

  /* Cuánto dura el video, medido acá antes de subirlo: un <video> sobre un
     objectURL alcanza y evita tener que abrirlo después para saberlo. */
  function medir(file) {
    return new Promise(function (res) {
      var url = URL.createObjectURL(file);
      var v = document.createElement('video');
      v.preload = 'metadata';
      v.onloadedmetadata = function () {
        var d = isFinite(v.duration) ? Math.round(v.duration) : 0;
        try { URL.revokeObjectURL(url); } catch (e) {}
        res(d);
      };
      v.onerror = function () {
        try { URL.revokeObjectURL(url); } catch (e) {}
        res(0);
      };
      v.src = url;
    });
  }

  /* Un tutorial es el primer video + hasta 30 `mas` (validar_tutoriales). */
  var MAX_PARTES = 31;
  var mbDe = function (b) { return Math.round(b / 1048576); };

  /* ⚠️ El tamaño se mira ANTES de mandar. Si el programa rechaza un video
     por grande, corta la conexión sin leerlo y el navegador solo dice «El
     panel no responde» (pasó el 29-sep con una capacitación de 600 MB). */
  function revisarTamano(file) {
    return window.api('/api/video-capacidad').then(function (cap) {
      var tope = cap.max_tutorial || cap.max_subida || 0;
      if (tope && file.size > tope) {
        throw new Error('«' + file.name + '» pesa ' + mbDe(file.size) + ' MB y lo máximo para un ' +
          'tutorial son ' + mbDe(tope) + ' MB. Partilo en dos antes de subirlo.');
      }
      if (cap.libre && file.size * 2.2 > cap.libre) {
        throw new Error('No hay lugar en el disco para «' + file.name + '»: hacen falta ' +
          mbDe(file.size * 2.2) + ' MB libres y hay ' + mbDe(cap.libre) + ' MB. Liberá espacio y probá de nuevo.');
      }
    }, function () { /* un panel viejo sin este dato: que decida el servidor */ });
  }

  /* Sube UN archivo y devuelve una LISTA de {src, duracion}: un video largo
     vuelve cortado en partes de pocos minutos que se ven una detrás de la otra.
     Lo usan «Subir un tutorial» y «Sumar otro video». */
  function subirArchivo(file, andando) {
    var clave = 'tut-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
    var fd = new FormData();
    fd.append('key', clave);
    fd.append('file', file);
    var duracion = 0;
    return revisarTamano(file).then(function () {
      return medir(file);
    }).then(function (d) {
      duracion = d;
      if (file.size > 200 * 1048576) andando('Pasando el video al panel (' + mbDe(file.size) + ' MB)…');
      return window.api('/api/upload-tutorial', { method: 'POST', body: fd });
    }).then(function (r) {
      if (r && r.falta_ffmpeg) {
        throw new Error('Este video hay que convertirlo y falta el compresor. ' +
          'Entrá a un módulo con video y aceptá bajarlo, o subí un mp4 más liviano.');
      }
      if (r && r.error) throw new Error(r.error);
      if (r && r.job) {
        andando('Achicando el video… 0%');
        return window.esperarJob(r.job, function (j) {
          andando((j.msg || 'Achicando el video…') + ' ' + (j.pct || 0) + '%' +
            (file.size > 200 * 1048576 ? ' — un video largo tarda, no cierres el panel' : ''));
        }).then(function (j) {
          return (j.partes && j.partes.length) ? j.partes : [{ src: j.src, duracion: duracion }];
        });
      }
      return [{ src: r.src, duracion: duracion }];
    });
  }

  /* varios archivos, en fila: uno por vez para no ahogar la compu */
  function subirVarios(files, andando) {
    var hechos = [];
    return files.reduce(function (cadena, f, i) {
      return cadena.then(function () {
        var pre = files.length > 1 ? 'Video ' + (i + 1) + ' de ' + files.length + ': ' : '';
        andando(pre + 'Subiendo…');
        return subirArchivo(f, function (x) { andando(pre + x); })
          .then(function (x) { hechos = hechos.concat(x); });
      });
    }, Promise.resolve()).then(function () { return hechos; });
  }

  function revisarPartes(total) {
    if (total > MAX_PARTES) {
      throw new Error('El tutorial quedaría con ' + total + ' partes y el máximo son ' + MAX_PARTES +
        '. Subí el resto como otro tutorial.');
    }
  }

  function sumarVideos(files) {
    var t = elDe(ABIERTO);
    if (!t) return;
    if (window.exigirActualizacion && window.exigirActualizacion()) return;
    var btn = document.getElementById('tutSumar');
    var paso = document.getElementById('tutSumarPaso');
    var andando = function (x) { if (paso) { paso.textContent = x || ''; paso.hidden = !x; } };
    if (btn) btn.disabled = true;
    subirVarios(files, andando).then(function (nuevos) {
      andando('Guardando…');
      var fresco = elDe(t.id) || t;
      revisarPartes(1 + (fresco.mas || []).length + nuevos.length);
      var copia = Object.assign({}, fresco, { mas: (fresco.mas || []).concat(nuevos) });
      return guardar(LISTA.map(function (x) { return x.id === t.id ? copia : x; }),
        nuevos.length === 1 ? 'Video sumado al final del tutorial'
                            : nuevos.length + ' videos sumados al final del tutorial');
    }).then(function () {
      andando('');
      pintar();
    }).catch(function (e) {
      andando('');
      if (btn) btn.disabled = false;
      aviso(e.message || 'No se pudo subir el video', 'err');
    });
  }

  /* Quitar uno de los videos: se van con él sus capítulos, y los de los
     videos que siguen se corren para atrás lo que duraba. */
  function quitarParte(i) {
    var t = elDe(ABIERTO);
    var ps = partes(t);
    if (!t || !ps[i] || ps.length < 2) return;
    var p = ps[i];
    var dentro = function (c) { return c.t >= p.desde && c.t < p.desde + p.duracion; };
    var suyos = (t.capitulos || []).filter(dentro).length;
    if (!window.confirm('¿Quitar el video ' + (i + 1) + ' de este tutorial?' +
        (suyos ? ' Se quitan también sus ' + suyos + (suyos === 1 ? ' capítulo.' : ' capítulos.') : ''))) return;
    var caps = (t.capitulos || []).filter(function (c) { return !dentro(c); }).map(function (c) {
      return c.t >= p.desde + p.duracion ? { t: Math.round(c.t - p.duracion), texto: c.texto } : c;
    });
    var lista = [{ src: t.src, duracion: t.duracion || 0 }].concat(t.mas || []);
    lista.splice(i, 1);
    var copia = Object.assign({}, t, {
      src: lista[0].src, duracion: lista[0].duracion, mas: lista.slice(1), capitulos: caps
    });
    guardar(LISTA.map(function (x) { return x.id === t.id ? copia : x; }), 'Video quitado')
      .then(pintar)
      .catch(function (e) { aviso(e.message || 'No se pudo quitar', 'err'); });
  }

  function subir() {
    var titulo = (document.getElementById('tutTitulo').value || '').trim();
    var nota = (document.getElementById('tutNota').value || '').trim();
    var files = [].slice.call(document.getElementById('tutArchivo').files || []);
    var file = files[0];
    var mal = document.getElementById('tutSubirMal');
    var paso = document.getElementById('tutSubirPaso');
    var decir = function (t) {
      mal.textContent = t; mal.hidden = !t;
    };
    var andando = function (t) {
      paso.textContent = t || ''; paso.hidden = !t;
    };
    if (!titulo) { decir('Ponele un nombre al tutorial.'); return; }
    if (!file) { decir('Elegí el video.'); return; }
    decir('');
    var btn = document.getElementById('tutSubir');
    btn.disabled = true;
    andando('Subiendo el video…');

    var clave = 'tut-' + Date.now().toString(36);
    subirVarios(files, andando).then(function (vids) {
      andando('Guardando…');
      revisarPartes(vids.length);
      var src = vids[0].src;
      var nuevo = {
        id: clave, titulo: titulo, nota: nota, src: src,
        duracion: vids[0].duracion, capitulos: [],
        creado: new Date().toISOString().slice(0, 10)
      };
      if (vids.length > 1) nuevo.mas = vids.slice(1);
      return guardar([nuevo].concat(LISTA), 'Tutorial subido').then(function (l) {
        return { lista: l, src: src };
      });
    }).then(function (r) {
      btn.disabled = false; andando('');
      cerrarSubir();
      /* ⚠️ El id se busca POR EL VIDEO, no se da por sentado. El servidor
         normaliza la clave —«tut-abc» le vuelve como «tut_abc»—, así que dar
         por hecha la que se mandó dejaba abierto un tutorial que no existe y
         la pantalla volvía a la lista sin decir por qué. */
      var puesto = (r.lista || []).filter(function (t) { return t.src === r.src; })[0];
      ABIERTO = puesto ? puesto.id : null;
      pintar();
    }).catch(function (e) {
      btn.disabled = false; andando('');
      decir(e.message || 'No se pudo subir el video.');
    });
  }

  /* ───────────── los clicks de la sección ───────────── */
  document.addEventListener('click', function (ev) {
    if (!ev.target.closest) return;
    var r = raiz();
    if (!r) return;
    var ver = ev.target.closest('[data-ver-tut]');
    if (ver && ver.dataset.t) {          /* resultado de la lupa: entra al minuto */
      ABIERTO = ver.getAttribute('data-ver-tut'); EDIT = false; pintar();
      irA(parseInt(ver.dataset.t, 10) || 0, true);
      return;
    }
    if (ver && r.contains(ver)) {
      ABIERTO = ver.getAttribute('data-ver-tut'); EDIT = false; pintar(); return;
    }
    var x = ev.target.closest('[data-borrar-tut]');
    if (x && r.contains(x)) {
      var id = x.getAttribute('data-borrar-tut');
      var t = elDe(id);
      if (!t || !window.confirm('¿Quitar el tutorial "' + t.titulo + '"? ' +
                                'Se borra también el video.')) return;
      guardar(LISTA.filter(function (y) { return y.id !== id; }), 'Tutorial quitado')
        .then(pintar);
      return;
    }
    var cap = ev.target.closest('.tut-cap:not(.edit)');
    if (cap && r.contains(cap)) {
      irA(parseInt(cap.dataset.t, 10) || 0, true);
      return;
    }
    var qp = ev.target.closest('[data-quitar-parte]');
    if (qp && r.contains(qp)) { quitarParte(parseInt(qp.dataset.quitarParte, 10)); return; }
    var hv = ev.target.closest('.tut-vid-h[data-parte]');
    if (hv && r.contains(hv)) {
      var pp = partes(elDe(ABIERTO))[parseInt(hv.dataset.parte, 10)];
      if (pp) irA(pp.desde, true);
      return;
    }
  });

  document.addEventListener('click', function (ev) {
    if (!ev.target.closest) return;
    if (ev.target.closest('[data-cerrar-tut]')) { cerrarSubir(); return; }
    if (ev.target.id === 'tutSubir') { subir(); }
  });

  /* La sección se pinta al ENTRAR, no al abrir el panel: traer la lista es un
     viaje al servidor que nadie pidió mientras mira la cartelera. */
  window.refrescarTutoriales = function () {
    if (!CARGADO) { cargar(); return; }
    pintar();
  };
}());
